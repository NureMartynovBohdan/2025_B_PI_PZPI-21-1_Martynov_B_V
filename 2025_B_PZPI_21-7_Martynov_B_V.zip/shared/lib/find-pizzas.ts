import { prisma } from '@/prisma/prisma-client';

const DEFAULT_MIN_PRICE = 0;
const DEFAULT_MAX_PRICE = 1000;

export const findPizzas = async (params: Record<string, string | string[] | undefined>) => {
  const parseNumberArray = (value?: string | string[]) =>
    typeof value === 'string' ? value.split(',').map(Number) : undefined;

  const parseSingleNumber = (value?: string | string[]) => {
    const num = Number(typeof value === 'string' ? value : undefined);
    return isNaN(num) ? undefined : num;
  };

  const sizes = parseNumberArray(params.sizes);
  const pizzaTypes = parseNumberArray(params.pizzaTypes);
  const ingredientsIdArr = parseNumberArray(params.ingredients);

  const minPrice = parseSingleNumber(params.priceFrom) ?? DEFAULT_MIN_PRICE;
  const maxPrice = parseSingleNumber(params.priceTo) ?? DEFAULT_MAX_PRICE;

  const categories = await prisma.category.findMany({
    include: {
      products: {
        orderBy: {
          id: 'desc',
        },
        where: {
          ingredients: ingredientsIdArr?.length
            ? {
              some: {
                id: {
                  in: ingredientsIdArr,
                },
              },
            }
            : undefined,
          items: {
            some: {
              size: sizes?.length ? { in: sizes } : undefined,
              pizzaType: pizzaTypes?.length ? { in: pizzaTypes } : undefined,
              price: {
                gte: minPrice,
                lte: maxPrice,
              },
            },
          },
        },
        include: {
          ingredients: true,
          items: {
            where: {
              price: {
                gte: minPrice,
                lte: maxPrice,
              },
            },
            orderBy: {
              price: 'asc',
            },
          },
        },
      },
    },
  });

  return categories;
};
