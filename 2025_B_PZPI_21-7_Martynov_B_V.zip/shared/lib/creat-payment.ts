import crypto from 'crypto';

interface Props {
  description: string;
  orderId: number;
  amount: number;
}

export async function createLiqPayPayment(details: Props) {
  const public_key = process.env.LIQPAY_PUBLIC_KEY!;
  const private_key = process.env.LIQPAY_PRIVATE_KEY!;

  // Параметри запроса к LiqPay API
  const params = {
    version: '3',
    public_key,
    action: 'pay',
    amount: details.amount.toString(),
    currency: 'UAH',
    description: details.description,
    order_id: details.orderId.toString(),
    language: 'ua',
    result_url: process.env.LIQPAY_RESULT_URL,
    server_url: process.env.LIQPAY_CALLBACK_URL,
  };

  // Base64-кодування JSON-строки 
  const data = Buffer.from(JSON.stringify(params)).toString('base64');

  // Підпис: SHA1(private_key + data + private_key), потім base64
  const signature = crypto
    .createHash('sha1')
    .update(private_key + data + private_key)
    .digest('base64');

  // 3) URL для користувача
  const paymentUrl = `https://www.liqpay.ua/api/3/checkout?data=${data}&signature=${signature}`;

  return { data, signature, paymentUrl };
}