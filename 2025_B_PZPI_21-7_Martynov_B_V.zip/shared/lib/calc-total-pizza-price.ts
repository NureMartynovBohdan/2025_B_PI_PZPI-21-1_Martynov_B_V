import { Ingredient, ProductItem } from '@prisma/client';
import { PizzaSize, PizzaType } from '../constants/pizza';

/**
 * Функція для підрахунку загальної вартості піци
 *
 * @param type - тип тіста обраної піци
 * @param size - розмір обраної піци
 * @param items - список варіантів (ProductItem[]) з цінами
 * @param ingredients - список всіх інгредієнтів (Ingredient[])
 * @param selectedIngredients - множина ідентифікаторів обраних інгредієнтів (Set<number>)
 *
 * @returns number - загальна вартість
 */
export const calcTotalPizzaPrice = (
   type: PizzaType,
   size: PizzaSize,
   items: ProductItem[],
   ingredients: Ingredient[],
   selectedIngredients: Set<number>,
): number => {
   const pizzaPrice =
      items.find((item) => item.pizzaType === type && item.size === size)?.price || 0;

   const ingredientsPrice = ingredients
      .filter((ing) => selectedIngredients.has(ing.id))
      .reduce((sum, ing) => sum + ing.price, 0);

   return pizzaPrice + ingredientsPrice;
};
