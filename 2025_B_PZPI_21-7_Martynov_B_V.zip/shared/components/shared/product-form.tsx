'use client';

import { ProductWithRelations } from '@/@types/prisma';
import { useCartStore } from '@/shared/store';
import React from 'react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { ChooseProductForm } from './choose-product-form';
import { ChoosePizzaForm } from './choose-pizza-form';

interface Props {
   product: ProductWithRelations;
   className?: string;
}

export const ProductForm: React.FC<Props> = ({ product }) => {
   const router = useRouter();
   const firstItem = product.items[0];
   const isPizzaForm = Boolean(firstItem.pizzaType);

   const addCartItem = useCartStore((state) => state.addCartItem);
   const loading = useCartStore((state) => state.loading);

   const onSubmit = async (productItemId?: number, ingredients?: number[]) => {
      try {
         const itemId = productItemId ?? firstItem.id;

         await addCartItem({
            productItemId: itemId,
            ingredients,
         });

         toast.success(`Товар "${product.name}" додано до кошика`);
      } catch (err) {
         toast.error('Не вдалося додати товар до кошика');
         console.error(err);
      }
   };
   if (isPizzaForm) {
      return (
         <ChoosePizzaForm
            imageUrl={product.imageUrl}
            name={product.name}
            items={product.items}
            ingredients={product.ingredients}
            onSubmit={onSubmit}
            loading={loading}
         />
      );
   }
   return (
      <ChooseProductForm
         imageUrl={product.imageUrl}
         name={product.name}
         onSubmit={() => onSubmit()}
         price={firstItem.price}
         loading={loading}
      />)
};
