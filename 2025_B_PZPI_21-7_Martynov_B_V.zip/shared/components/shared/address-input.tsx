'use client';

import React, { useRef, useState } from 'react';
import Autocomplete from 'react-google-autocomplete';
import { GoogleMap, Marker, useJsApiLoader } from '@react-google-maps/api';

interface Props {
   onChange?: (value?: string) => void;
}

const containerStyle = {
   width: '100%',
   height: '300px',
};

export const AdressInput: React.FC<Props> = ({ onChange }) => {
   const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
   const [address, setAddress] = useState<string>('');
   const autocompleteRef = useRef<HTMLInputElement>(null);

   const { isLoaded } = useJsApiLoader({
      googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_API_KEY!,
      libraries: ['places'],
      language: 'uk',
   });

   const handlePlaceSelect = (place: google.maps.places.PlaceResult) => {
      const formattedAddress = place.formatted_address;
      const lat = place.geometry?.location?.lat();
      const lng = place.geometry?.location?.lng();

      if (lat && lng) {
         setLocation({ lat, lng });
      }

      if (formattedAddress) {
         setAddress(formattedAddress);
         onChange?.(formattedAddress);
      }
   };

   const handleMapClick = async (e: google.maps.MapMouseEvent) => {
      if (e.latLng) {
         const lat = e.latLng.lat();
         const lng = e.latLng.lng();
         setLocation({ lat, lng });

         const geocoder = new google.maps.Geocoder();
         geocoder.geocode({ location: { lat, lng } }, (results, status) => {
            if (status === 'OK' && results?.[0]) {
               const resultAddress = results[0].formatted_address;
               setAddress(resultAddress);
               onChange?.(resultAddress);
               if (autocompleteRef.current) {
                  autocompleteRef.current.value = resultAddress;
               }
            }
         });
      }
   };

   if (!isLoaded) return <p>Завантаження карти…</p>;

   return (
      <div className="flex flex-col gap-4">
         <Autocomplete
            apiKey={process.env.NEXT_PUBLIC_GOOGLE_API_KEY}
            onPlaceSelected={handlePlaceSelect}
            options={{
               types: ['address'],
               componentRestrictions: { country: 'ua' },
            }}
            className="text-base w-full border px-4 py-2 rounded-xl"
            placeholder="Введить адресу..."
            ref={autocompleteRef}
         />

         {location && (
            <GoogleMap
               mapContainerStyle={containerStyle}
               center={location}
               zoom={15}
               onClick={handleMapClick}
            >
               <Marker position={location} />
            </GoogleMap>
         )}
      </div>
   );
};