'use client';

import { useCartStore } from '../store';
import { CreateCartItemValues } from '../services/dto/cart.dto';
import { CartStateItem } from '../lib/get-cart-details';
import React from 'react';

type ReturnProps = {
  totalAmount: number;
  items: CartStateItem[];
  loading: boolean;
  fetchCartItems: () => void;
  updateItemQuantity: (id: number, quantity: number) => void;
  removeCartItem: (id: number) => void;
  addCartItem: (values: CreateCartItemValues) => void;
};

export const useCart = (): ReturnProps => {
  const cartState = useCartStore((state) => state);

  const fetchCartItems = useCartStore((state) => state.fetchCartItems);

  React.useEffect(() => {
    fetchCartItems();
  }, [fetchCartItems]);

  return {
    totalAmount: cartState.totalAmount,
    items: cartState.items,
    loading: cartState.loading,
    fetchCartItems: cartState.fetchCartItems,
    updateItemQuantity: cartState.updateItemQuantity,
    removeCartItem: cartState.removeCartItem,
    addCartItem: cartState.addCartItem,
  };
};

function useEffect(arg0: () => void, arg1: (() => Promise<void>)[]) {
  throw new Error('Function not implemented.');
}
