export enum ApiRoutes {
   SEARCH_PRODUCTS = '/products/search',
   INGRIDIENTS = '/ingredients',
   STORY = '/stories',
}

