import { Story, StoryItem } from '@prisma/client';
import { axiosInstance } from './instance';
import { ApiRoutes } from './constants';

export type IStory = Story & {
  items: StoryItem[];
};

export const getAll = async () => {
  return (await axiosInstance.get<IStory[]>(ApiRoutes.STORY)).data;
};
