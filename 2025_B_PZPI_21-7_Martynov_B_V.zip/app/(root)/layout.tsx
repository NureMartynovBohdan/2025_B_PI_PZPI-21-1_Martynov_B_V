import { Header } from '@/shared/components/shared';
import { Metadata } from 'next';
import { Suspense } from 'react';

export const metadata: Metadata = {
  title: 'Nure Pizza | Головна',
};

export default function HomeLayout({
  children,
  modal,
}: Readonly<{
  children: React.ReactNode;
  modal: React.ReactNode;
}>) {
  return (
    <main>
      <Suspense>
        <Header hasSearch={true} hasCart={true} />
      </Suspense>
      {children}
      {modal}
    </main>
  );
}
