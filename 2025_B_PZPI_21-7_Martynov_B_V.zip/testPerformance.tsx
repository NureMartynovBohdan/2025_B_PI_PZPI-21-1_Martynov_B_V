const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function testPerformance() {
   const startTime = Date.now();

   const productsWithMozzarella = await prisma.product.findMany({
      where: {
         ingredients: {
            some: { name: "Сир Моцарела" }
         }
      },
      include: {
         // Фільтруємо лише інгредієнти з ім'ям "Сир Моцарела"
         ingredients: {
            where: { name: "Сир Моцарела" }
         }
      }
   });

   const duration = Date.now() - startTime;
   console.log("Час виконання Prisma-запиту:", duration, "ms");
   console.log(JSON.stringify(productsWithMozzarella, null, 2));
}

testPerformance()
   .catch((e) => {
      console.error(e);
   })
   .finally(async () => {
      await prisma.$disconnect();
   });
