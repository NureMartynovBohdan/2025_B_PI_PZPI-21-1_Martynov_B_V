// exportData.js
const { PrismaClient } = require('@prisma/client');
const fs = require('fs');

const prisma = new PrismaClient();

async function exportData() {
   try {
      // Извлекаем данные из нужных моделей
      const users = await prisma.user.findMany();
      const categories = await prisma.category.findMany();
      const products = await prisma.product.findMany();
      const ingredients = await prisma.ingredient.findMany();
      const orders = await prisma.order.findMany();
      // Если у вас есть дополнительные модели, добавьте их сюда

      // Собираем все данные в один объект
      const data = {
         users,
         categories,
         products,
         ingredients,
         orders,
      };

      // Записываем данные в файл export.json с форматированием
      fs.writeFileSync('export.json', JSON.stringify(data, null, 2));
      console.log('Данные успешно экспортированы в файл export.json');
   } catch (error) {
      console.error('Ошибка при экспорте данных:', error);
   } finally {
      await prisma.$disconnect();
   }
}

exportData();
