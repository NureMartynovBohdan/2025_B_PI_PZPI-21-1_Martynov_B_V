import { Ingredient, Product, ProductItem } from '@prisma/client';
/*
type CategoryProducts = Category & {
  products: Array<Product & { items: ProductItem[] }>;
};
*/
export type ProductWithRelations = Product & { items: ProductItem[]; ingredients: Ingredient[] };
