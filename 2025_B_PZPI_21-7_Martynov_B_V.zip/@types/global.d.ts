type SearchParams = {
  query?: string;
  page?: string;
};

type IdParams = {
  id?: string;
};
